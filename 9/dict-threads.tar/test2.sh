#!/bin/bash
# get
gcc -o test2 test2.c dict.c -pthread
./test2
