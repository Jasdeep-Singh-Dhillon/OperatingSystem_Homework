#!/bin/bash
# set/clear/get
gcc -o test3 test3.c dict.c -pthread
./test3
