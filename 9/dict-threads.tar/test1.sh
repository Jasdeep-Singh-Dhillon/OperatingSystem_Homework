#!/bin/bash
# set/set/get
gcc -o test1 test1.c dict.c -pthread
./test1
