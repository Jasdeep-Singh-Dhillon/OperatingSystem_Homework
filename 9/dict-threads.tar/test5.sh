#!/bin/bash
# set/clear
gcc -o test5 test5.c dict.c -pthread
./test5
