#!/bin/bash
# set/set/get
gcc -o test4 test4.c dict.c -pthread
./test4
