#!/bin/bash
# test 1
test $(./parens <<< "a") = yes
