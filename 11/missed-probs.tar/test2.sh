#!/bin/bash
# shuffled numeric problems

# get output
rm -f temp-out.txt
awk -f missed-probs.awk < scores2.csv > temp-out.txt
diff -w temp-out.txt test2.csv > diffs.txt
