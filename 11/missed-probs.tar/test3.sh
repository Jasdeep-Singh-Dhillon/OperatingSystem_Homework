#!/bin/bash
# non-numeric problems

# get output
rm -f temp-out.txt
awk -f missed-probs.awk < scores3.csv > temp-out.txt
diff -w temp-out.txt test3.csv > diffs.txt
