#!/bin/bash
# sequential numeric problems

# get output
rm -f temp-out.txt
awk -f missed-probs.awk < scores1.csv > temp-out.txt
diff -w temp-out.txt test1.csv > diffs.txt
